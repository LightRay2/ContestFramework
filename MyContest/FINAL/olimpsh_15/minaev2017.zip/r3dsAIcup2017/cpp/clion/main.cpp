#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

double dist2(double x1, double y1, double x2, double y2) {
    return pow(x1 - x2, 2) + pow(y1 - y2, 2);
}


int main(int argc, char **argv) {
    cout.sync_with_stdio(false);
    cin.sync_with_stdio(false);

    ifstream fin("input.txt");
    ofstream fout("output.txt");
    fin.sync_with_stdio(false);
    fout.sync_with_stdio(false);

    int n;
    fin >> n >> n >> n;
    double mx, my, ox, oy;

    fin >> mx >> my >> ox >> oy;

    fin >> n;
    double tx = 50, ty = 50;
    double myCurDist = 10000;

    for (size_t i = 0; i < n; i++)
    {
        double x, y;
        fin >> x >> y;
        double dm = dist2(x, y, mx, my);
        double de = dist2(x, y, ox, oy);
        if (dm < de && dm < myCurDist) {
            myCurDist = dm;
            tx = x;
            ty = y;
        }
    }
    fout << tx << " " << ty << endl;

    fout.close();
    return 0;
}
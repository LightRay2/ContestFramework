import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;
import java.util.Scanner;

import static java.lang.Math.pow;

/**
 * Created by Jovfer on 02.04.2017.
 */
public class Main {

    static double dist2(double x1, double y1, double x2, double y2) {
        return pow(x1 - x2, 2) + pow(y1 - y2, 2);
    }

    static class Point {
        double x, y;
        double tx, ty;

        public Point(double x, double y) {
            this.x = x;
            this.y = y;
        }

        public Point(double x, double y, double tx, double ty) {
            this.x = x;
            this.y = y;
            this.tx = tx;
            this.ty = ty;
        }


        public boolean havePoint(Point boll) {
            return Math.abs(this.x - boll.x) < 1 && Math.abs(this.y - boll.y) < 1;
        }

        @Override
        public String toString() {
            return "Point{" +
                    "x=" + x +
                    ", y=" + y +
                    '}';
        }
    }

    static Point[] d = new Point[]{new Point(25, 20), new Point(25, 40)};

    public static void main(String[] args) {
        try {
            new Main().run();
        }catch (Throwable t) {
            /* nothing */
        }
    }

    static int H = 60;
    static int Hhalf = 30;
    static int W = 100;
    static int Whalf = 50;

    public void run() throws IOException {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(new File("input.txt"));
        sc.nextInt(); sc.nextInt(); sc.nextInt();
        Point boll = new Point(sc.nextDouble(), sc.nextDouble(), sc.nextDouble(), sc.nextDouble());
        int withBoll = 10;
        Point players[] = new Point[10];
        for (int i = 0; i < 10; i++) {
            players[i] = new Point(sc.nextDouble(), sc.nextDouble());
            if (i < 5 && players[i].havePoint(boll)) {
                withBoll = i;
            }
        }


        FileWriter fileWriter = new FileWriter("output.txt");

        for (int i = 0; i < 4; i++) {
            fileWriter.write(String.format("%f %f\n", boll.x, boll.y));
        }
//        for (int i = 0; i < 2; i++) {
            fileWriter.write(String.format("%f %f\n", 30f, boll.y));
//        }

//        if (withBoll < 5) {
            fileWriter.write(String.format("%f %f\n", boll.x+50, boll.y /*> Hhalf ? boll.y - 50 : boll.y + 50*/));
//        } else {
//            fileWriter.write(String.format("%f %f\n", d[1].x, d[1].y));
//        }

        fileWriter.close();

    }
}

package ru.dk;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

public class Main {

    private final double velocityOfBool = 6.0f;
    private final double velocityWithoutBool = 2.0f;
    private final double velocityWithBool = 2.5f;

    private final int playersAmount = 5;

    private final String prefixToMemory_withSpace = "memory ";
    private final String boolMainConst = "Bool_Is_Main";
    private final String boolTheirConst = "Bool_Is_Their";

    //--------------------------
    private Point boolPoint;
    private Point boolEndPoint;
    private Point[] myPlayers;
    private Point[] theirPlayers;
    private String memoryMessage;
    //--------------------------

    private boolean isBoolInSomeTeam(final Point[] playersToCheck) {
        for (final Point player : playersToCheck) {
            if (boolPoint.samePoint(player)) {
                return true;
            }
        }
        return false;
    }

    private boolean boolIsMain() {
        final boolean boolMain = isBoolInSomeTeam(myPlayers);
        final boolean boolTheir = isBoolInSomeTeam(theirPlayers);

        final boolean noOneHasBool = !boolMain && !boolTheir;

//        (noOneHasBool && boolMainConst.equals(memoryMessage)) ||

        return boolMain;
    }

    private double defenitionBetweenPoints(final Point p1, final Point p2) {
        return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
    }

    Point[] myPlayersToGo = new Point[playersAmount];
    Point boolToFireTo = null;

    Point p1ClosestToBall;
    Point p2ClosestToBall;
    List<Point> otherPlayers;

    private boolean passive() {
        try {
            final int memoryMessageInt = Integer.parseInt(memoryMessage);

            if (memoryMessageInt == 15) {
                return true;
            }
            memoryMessage = "1";
        } catch (Throwable t) {
            return false;
        }
        return false;
    }

    private void run() throws IOException {
        try {
            initInputData();
            Point boolToGo;
            String messageToWrite = null;

            myPlayersToGo[0] = boolPoint.clonePoint();
            myPlayersToGo[1] = boolPoint.clonePoint();
            myPlayersToGo[2] = boolPoint.clonePoint();
            myPlayersToGo[3] = boolPoint.clonePoint();
            myPlayersToGo[4] = boolPoint.clonePoint();

            try {
                final Map<Point, Double> mapWithDefinitions = new LinkedHashMap<>();
                for (Point p : myPlayers) {
                    mapWithDefinitions.put(p, defenitionBetweenPoints(p, boolPoint));
                }

                {
                    AtomicReference<Point> maxP = new AtomicReference<>();
                    AtomicReference<Double> maxDefinition = new AtomicReference<>(1000d);
                    mapWithDefinitions.forEach((p, d) -> {
                        if (d < maxDefinition.get()) {
                            maxP.set(p);
                            maxDefinition.set(d);
                        }
                    });
                    p1ClosestToBall = maxP.get();
                }

                {
                    AtomicReference<Point> maxP = new AtomicReference<>();
                    AtomicReference<Double> maxDefinition = new AtomicReference<>(1000d);
                    mapWithDefinitions.forEach((p, d) -> {
                        if (d < maxDefinition.get() && p != p1ClosestToBall) {
                            maxP.set(p);
                            maxDefinition.set(d);
                        }
                    });
                    p2ClosestToBall = maxP.get();
                }

                otherPlayers = mapWithDefinitions.keySet().stream()
                        .filter(p -> p != p1ClosestToBall && p != p2ClosestToBall)
                        .collect(Collectors.toList());

            } catch (Exception e) {
                messageToWrite = e.toString() + " [ " + e.getMessage() + " ]";
            }

            if (boolIsMain()) {
                messageToWrite = "Bool is Main";
                strategicIfBoolIsMain();
            } else {
                messageToWrite = "Bool is not Main";
                strategicIfBoolIsNotMain();
            }

            writeOutput(myPlayersToGo, boolToFireTo, messageToWrite);
        } catch (Exception e) {
            String msg = e.toString() + " [ " + e.getMessage() + " ]";
            Point[] pArr = new Point[5];
            if (boolPoint != null) {
                pArr[0] = boolPoint.clonePoint();
                pArr[1] = boolPoint.clonePoint();
                pArr[2] = boolPoint.clonePoint();
                pArr[3] = boolPoint.clonePoint();
                pArr[4] = boolPoint.clonePoint();
            } else {
                pArr[0] = new Point(10.0f, 10.0f);
                pArr[1] = new Point(10.0f, 10.0f);
                pArr[2] = new Point(10.0f, 10.0f);
                pArr[3] = new Point(10.0f, 10.0f);
                pArr[4] = new Point(10.0f, 10.0f);
            }
            writeOutput(pArr, null, msg);
        }
    }

    private float radius = 2.0f;

    boolean noOneAroundInRadius(final Point player) {
        if (player == null) return false;

        for (Point their : theirPlayers) {
            if (defenitionBetweenPoints(player, their) < 2.0f) {
                return false;
            }
        }

        return true;
    }

    void strategicIfBoolIsMain() {

        Point playerWithBoll = null;
        final List<Point> others = new LinkedList<>();
        for (Point player : myPlayers) {
            if (player.samePoint(boolPoint)) {
                playerWithBoll = player;
            } else {
                others.add(player);
            }
        }

        if (noOneAroundInRadius(playerWithBoll)) {
            //left all players save position in availability to each other
            //move player with boll straight
            boolean topAllowed = true;
            boolean centerAllowed = true;
            boolean bottomAllowed = true;

            for (int i = 0; i < playersAmount; i++) {
                final Point currentPlayer = myPlayers[i];

                if (currentPlayer.samePoint(playerWithBoll)) {
                    myPlayersToGo[i] = new Point(currentPlayer.x + 10f, currentPlayer.y);

                    if (100f - playerWithBoll.x < 25.0) {
                        boolToFireTo = new Point(100.0f, boolPoint.y);
                    }
                } else {
                    if (topAllowed && currentPlayer.y < 20) {
                        myPlayersToGo[i] = new Point(currentPlayer.x + 10f, 10);
                        topAllowed = false;
                    } else if (centerAllowed && currentPlayer.y < 40) {
                        myPlayersToGo[i] = new Point(boolPoint.x + 2.5f, 30);
                        centerAllowed = false;
                    } else if (bottomAllowed) {
                        myPlayersToGo[i] = new Point(currentPlayer.x + 10f, 50);
                        bottomAllowed = false;
                    } else {
                        myPlayersToGo[i] = new Point(currentPlayer.x + 10f, currentPlayer.y);
                    }
                }
            }

        } if (passive()) {
            for (int i = 0; i < playersAmount; i++) {
                final Point currentPlayer = myPlayers[i];
                myPlayersToGo[i] = new Point(currentPlayer.x + 2.5, currentPlayer.y);
            }
        } else {
            AtomicReference<Point> pointToPassIn = new AtomicReference<>();

            final Point finalPlayerWithBool = playerWithBoll;
            final List<Point> orderedPlayersByDifinition = others.stream().sorted((left, right) -> {
                final double definitionLeft = defenitionBetweenPoints(left, finalPlayerWithBool);
                final double definitionRight = defenitionBetweenPoints(right, finalPlayerWithBool);
                if (definitionLeft < definitionRight) {
                    return 1;
                } else if (definitionLeft > definitionRight) {
                    return -1;
                } else {
                    return 0;
                }
            }).collect(Collectors.toList());

            if (orderedPlayersByDifinition.stream().anyMatch(p -> defenitionBetweenPoints(finalPlayerWithBool, p) <= 12.0)) {
                final List<Point> cutList  =orderedPlayersByDifinition.stream()
                        .filter(p -> defenitionBetweenPoints(finalPlayerWithBool, p) <= 12.0)
                        .collect(Collectors.toList());

                double minDefinitio = 0;
                Point orientedPoint = null;
                for (Point p : cutList) {
                    double minDif = 1000;
                    for (Point pTheir : theirPlayers) {
                        if (minDif > defenitionBetweenPoints(pTheir, p)) {
                            minDif = defenitionBetweenPoints(pTheir, p);
                        }
                    }
                    if (minDefinitio < minDif) {
                        orientedPoint = p;
                        minDefinitio = minDif;
                    }
                }

                pointToPassIn.set(orientedPoint);
            } else {
                pointToPassIn.set(orderedPlayersByDifinition.get(0));
            }

            boolToFireTo = pointToPassIn.get();
            {
                boolean topAllowed = true;
                boolean centerAllowed = true;
                boolean bottomAllowed = true;

                for (int i = 0; i < playersAmount; i++) {
                    final Point currentPlayer = myPlayers[i];

                    if (currentPlayer.samePoint(playerWithBoll)) {
                        if (100f - playerWithBoll.x < 25.0) {
                            boolToFireTo = new Point(100.0f, boolPoint.y);
                        }
                        myPlayersToGo[i] = new Point(currentPlayer.x + 5f, pointToPassIn.get().y);
                    } else if (currentPlayer.samePoint(pointToPassIn.get())) {
                        myPlayersToGo[i] = boolPoint.clonePoint();
                    } else {

                        if (topAllowed && currentPlayer.y < 20) {
                            myPlayersToGo[i] = new Point(currentPlayer.x + 10, 10);
                            topAllowed = false;
                        } else if (centerAllowed && currentPlayer.y < 40) {
                            myPlayersToGo[i] = new Point(currentPlayer.x + 5, 30);
                            centerAllowed = false;
                        } else if (bottomAllowed) {
                            myPlayersToGo[i] = new Point(currentPlayer.x + 2, 50);
                            bottomAllowed = false;
                        } else {
                            myPlayersToGo[i] = new Point(currentPlayer.x + 15, currentPlayer.y);
                        }

                    }
                }
            }
        }
    }

    private Point srPoint(final Point a, final Point b) {
        final double x = (a.x + b.x) / 2.0;
        final double y = (a.y + b.y) / 2.0;
        return new Point(x, y);
    }

    void strategicIfBoolIsNotMain() {
        boolean topAllowed = true;
        boolean centerAllowed = true;
        boolean bottomAllowed = true;

        for (int i = 0; i < playersAmount; i++) {
            final Point currentPlayer = myPlayers[i];

            if (currentPlayer == p1ClosestToBall) {
                //strategic for closest
                myPlayersToGo[i] = srPoint(boolPoint, boolEndPoint);
            } else if (currentPlayer == p2ClosestToBall) {
                //strategic for second closest
                final Point srPoint = srPoint(boolPoint, boolEndPoint);
                myPlayersToGo[i] = new Point(srPoint.x, srPoint.y - 2.0);
            } else {
                if (topAllowed && currentPlayer.y < 20) {
                    myPlayersToGo[i] = new Point(boolPoint.x - 2.5f, 10);
                    topAllowed = false;
                } else if (centerAllowed && currentPlayer.y < 40) {
                    myPlayersToGo[i] = new Point(boolPoint.x - 2.5f, 30);
                    centerAllowed = false;
                } else if (bottomAllowed) {
                    myPlayersToGo[i] = new Point(boolPoint.x - 2.5f, 50);
                    bottomAllowed = false;
                } else {
                    myPlayersToGo[i] = new Point(boolPoint.x - 2.5f, currentPlayer.y);
                }
            }
        }
    }

    void writeOutput(final Point[] myPlayersToGo,
                     final Point boolToGo,
                     final String messageWithoutPrefix) throws IOException {
        try (final BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"))) {
            for (Point pointToWrite : myPlayersToGo) {
                final String toWrite = pointToWrite.x + " " + pointToWrite.y;
                writer.write(toWrite);
                writer.newLine();
            }

            if (boolToGo != null) {
                final String toWrite = boolToGo.x + " " + boolToGo.y;

                writer.write(toWrite);
                writer.newLine();
            }

            if (messageWithoutPrefix != null) {
                try {
                    final int memoryMessageIntVal = Integer.parseInt(memoryMessage);
                    writer.write(prefixToMemory_withSpace + String.valueOf(memoryMessageIntVal + 1));
                    writer.newLine();
                } catch (Throwable t) {
                    writer.write(prefixToMemory_withSpace + messageWithoutPrefix);
                    writer.newLine();
                }
            } else {
                final String passiveCount = "1";
                writer.write(prefixToMemory_withSpace + passiveCount);
                writer.newLine();
            }

            writer.flush();
        }
    }

    void initInputData() throws IOException {
        String step = "zero";
        try {
            ReaderMy readerMy = new ReaderMy();
            final List<String> listLines = readerMy.getStringsFromText();

            step = "tickNumber";
            final ReaderMy.Parser p1 = new ReaderMy.Parser(listLines.get(0));
            final int tickNumber = Integer.parseInt(p1.getValue(0, " "));
            step = "mainWinBool";
            final int mainWinBool = Integer.parseInt(p1.getValue(1, " "));
            step = "theirWinBool";
            final int theirWinBool = Integer.parseInt(p1.getValue(2, " "));

            final ReaderMy.Parser p2 = new ReaderMy.Parser(listLines.get(1));
            { //init bool start point
                step = "init bool start point";
                final double pX = Double.parseDouble(p2.getValue(0, " "));
                final double pY = Double.parseDouble(p2.getValue(1, " "));

                boolPoint = new Point(pX, pY);
            }

            { //init bool end point
                step = "init bool end point";
                final double pX = Double.parseDouble(p2.getValue(2, " "));
                final double pY = Double.parseDouble(p2.getValue(3, " "));

                boolEndPoint = new Point(pX, pY);
            }

            for (int i = 0; i < playersAmount; i++) {
                final ReaderMy.Parser pI = new ReaderMy.Parser(listLines.get(2 + i));
                step = "init my player i: " + i;
                final double pX = Double.parseDouble(pI.getValue(0, " "));
                final double pY = Double.parseDouble(pI.getValue(1, " "));

                myPlayers[i] = new Point(pX, pY);
            }

            for (int i = 0; i < playersAmount; i++) {
                final ReaderMy.Parser pI = new ReaderMy.Parser(listLines.get(2 + i));
                step = "init their player i: " + i;
                final double pX = Double.parseDouble(pI.getValue(0, " "));
                final double pY = Double.parseDouble(pI.getValue(1, " "));

                theirPlayers[i] = new Point(pX, pY);
            }

            if (listLines.size() > 12) {
                step = "read message";
                memoryMessage = listLines.get(12);
            }
        } catch (Exception e) {
            String msg = e.toString() + " [ " + e.getMessage() + " ] (" + step + ")";
            Point[] pArr = new Point[5];
            pArr[0] = new Point(10.0f, 10.0f);
            pArr[1] = new Point(10.0f, 10.0f);
            pArr[2] = new Point(10.0f, 10.0f);
            pArr[3] = new Point(10.0f, 10.0f);
            pArr[4] = new Point(10.0f, 10.0f);
            writeOutput(pArr, null, msg);
            System.exit(0);
        }
    }

    Main() {
        this.myPlayers = new Point[playersAmount];
        this.theirPlayers = new Point[playersAmount];
    }

    public static void main(String[] args) throws IOException {
        new Main().run();
    }

    static class Point {
        double x;
        double y;

        Point(double x, double y) {
            this.x = x;
            this.y = y;
        }

        boolean samePoint(final Point point) {
            return x == point.x && y == point.y;
        }

        Point clonePoint() {
            return new Point(x, y);
        }

        @Override
        public boolean equals(Object o) {
            return this == o;
        }

    }
}

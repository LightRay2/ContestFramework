package ru.dk;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReaderMy {
    private BufferedReader reader;
    public static final String PATH = "input.txt";

    public ReaderMy() throws FileNotFoundException {
        reader = new BufferedReader(new FileReader(PATH));
    }

    public List<String> getStringsFromText() throws IOException {
        List<String> lines = new ArrayList<>();
        String line;
        while((line = reader.readLine()) != null) {
            lines.add(line);
        }
        //List<String> lines = new ArrayList<>();
        //lines.add("asdsad asasd");
        return lines;
    }

    public static class Parser {
        private String text;
        public Parser(String text) {
            this.text = text;
        }

        public String getValue(int index, String splitter) {
            String[] values = text.split(splitter);
            if(index >= values.length) {
                return "";
            }
            return values[index];
        }
    }


}
